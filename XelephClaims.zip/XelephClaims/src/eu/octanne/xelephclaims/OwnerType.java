package eu.octanne.xelephclaims;

public enum OwnerType {
	PLAYER(), REGION();
}
